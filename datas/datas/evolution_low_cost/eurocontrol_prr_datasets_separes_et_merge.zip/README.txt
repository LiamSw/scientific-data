# EUROCONTROL PRR source datasets — Low-cost vs Mainline

This package contains **four separate CSV files, one per PRR report edition** and a merge script.

Files to copy into your Jupyter notebook's data/ directory:
- prr_2022_lowcost_mainline.csv — 2022 (Figure 2-9), direct published daily averages
- prr_2023_lowcost_mainline.csv — 2023 (Figure 2-8), direct published daily averages
- prr_2024_lowcost_mainline.csv — 2019, 2024 (Figure 2-7 / executive summary); 2019 derived by subtracting published 2024 vs 2019 differences from 2024 levels
- prr_2025_lowcost_mainline.csv — 2025 (Figure 2-11), direct published daily averages

Run `merge_prr_datasets.py` from your notebook working directory (where `data/` lives), or paste its content into a Jupyter cell.

CSV structure: long format (year, market_segment, average_daily_ifr_flights, unit, report_edition, data_status, classification_version, source_figure, source_url, notes).

Final merged CSV is in wide format with one row per year and separate low-cost and mainline columns.

IMPORTANT:
- Both market segments are extracted from the **same report** for each reported year.
- Source CSV files here are transcriptions of the **published figures**, not official EUROCONTROL raw downloadable CSVs.
- `2019` values are **derived from rounded 2024 values and reported differences** (not directly published 2019 averages in this bundle).
- PRR 2025 uses revised market segment classification, applied retrospectively from January 2024; source PRR 2024 still gives its original publication.
- No 2020 or 2021 rows are present; no interpolation is carried out.
- Do not interpret 2024-to-2025 simple percent change in this mixed-edition data as an exact growth estimate. Official PRR 2025 changes versus adjusted 2024 are +6.4% (low-cost) and +4.3% (mainline).

Official publication landing pages:
- https://www.eurocontrol.int/publication/performance-review-report-prr-2022
- https://www.eurocontrol.int/publication/performance-review-report-prr-2023
- https://www.eurocontrol.int/publication/performance-review-report-prr-2024
- https://www.eurocontrol.int/publication/performance-review-report-prr-2025
- https://www.eurocontrol.int/publication/market-segment-rules
